
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- Subgroup: Basic Info -->
    <div class="col-span-2 border rounded p-4 bg-gray-50">
        <h2 class="text-lg font-semibold mb-4">Basic Info</h2>
        <p><strong>Project Name:</strong> {{ $project->ProjectName }}</p>
        <p><strong>Project Type:</strong> {{ $project->ProjectType }}</p>
        <p><strong>Project Status:</strong> {{ $project->ProjectStatus }}</p>
        <p><strong>Project Capacity (MW):</strong> {{ $project->ProjectCapacityMW }}</p>
    </div>

    <!-- Subgroup: Developer Info -->
    <div class="col-span-2 border rounded p-4 bg-gray-50">
        <h2 class="text-lg font-semibold mb-4">Developer Info</h2>
        <p><strong>Developer:</strong> {{ $project->Developer }}</p>
        <p><strong>ENV Developer HQ Address:</strong> {{ $project->ENVDeveloperHQAddress }}</p>
        <p><strong>ENV Developer Website:</strong> {{ $project->ENVDeveloperWebsite }}</p>
        <p><strong>ENV Developer Phone:</strong> {{ $project->ENVDeveloperHQPhone }}</p>
    </div>
</div>
