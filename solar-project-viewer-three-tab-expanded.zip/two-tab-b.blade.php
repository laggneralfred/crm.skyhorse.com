
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- Subgroup: Supplier Info -->
    <div class="col-span-2 border rounded p-4 bg-gray-50">
        <h2 class="text-lg font-semibold mb-4">Supplier Info</h2>
        <p><strong>Supplier:</strong> {{ $project->Supplier }}</p>
        <p><strong>Supplier Website:</strong> {{ $project->SupplierWebsite }}</p>
        <p><strong>Supplier HQ Address:</strong> {{ $project->SupplierHQAddress }}</p>
        <p><strong>Supplier HQ Phone:</strong> {{ $project->SupplierHQPhone }}</p>
    </div>

    <!-- Subgroup: Owner Info -->
    <div class="col-span-2 border rounded p-4 bg-gray-50">
        <h2 class="text-lg font-semibold mb-4">Owner Info</h2>
        <p><strong>Owner:</strong> {{ $project->Owner }}</p>
        <p><strong>ENVOwner Website:</strong> {{ $project->ENVOwnerWebsite }}</p>
        <p><strong>ENVOwner HQ Address:</strong> {{ $project->ENVOwnerHQAddress }}</p>
        <p><strong>ENVOwner HQ Phone:</strong> {{ $project->ENVOwnerHQPhone }}</p>
    </div>
</div>
