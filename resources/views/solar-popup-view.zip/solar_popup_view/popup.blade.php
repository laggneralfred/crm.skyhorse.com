@extends('components.layouts.solar')

@section('content')
<div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 h-screen overflow-y-auto">
    <h1 class="text-2xl font-bold text-center mb-6">Solar Project: {{ $project->ProjectName }}</h1>

    <div x-data="{ tab: 'tab1' }">
        <!-- Tabs -->
        <div class="flex flex-wrap justify-center space-x-4 border-b mb-6">
            <button @click="tab = 'tab1'" :class="tab === 'tab1' ? 'text-blue-600 font-bold border-b-2 border-blue-600' : 'text-gray-600'" class="px-3 py-2">Project Overview</button>
            <button @click="tab = 'tab2'" :class="tab === 'tab2' ? 'text-blue-600 font-bold border-b-2 border-blue-600' : 'text-gray-600'" class="px-3 py-2">Interconnection & Ownership</button>
            <button @click="tab = 'tab3'" :class="tab === 'tab3' ? 'text-blue-600 font-bold border-b-2 border-blue-600' : 'text-gray-600'" class="px-3 py-2">Performance & History</button>
        </div>

        <!-- Tab Contents -->
        <div x-show="tab === 'tab1'" x-cloak>
            @include('partials.popup.tab1')
        </div>
        <div x-show="tab === 'tab2'" x-cloak>
            @include('partials.popup.tab2')
        </div>
        <div x-show="tab === 'tab3'" x-cloak>
            @include('partials.popup.tab3')
        </div>
    </div>
</div>
@endsection
