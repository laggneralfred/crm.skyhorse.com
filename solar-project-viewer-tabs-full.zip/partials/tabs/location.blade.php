
<div class="bg-white shadow rounded p-6">
    <h2 class="text-xl font-semibold mb-4">Location Info</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="border rounded p-4 bg-gray-50">
            <p><strong>Address:</strong> {{ $project->Address }}</p>
            <p><strong>City:</strong> {{ $project->City }}</p>
            <p><strong>Zip Code:</strong> {{ $project->ZipCode }}</p>
            <p><strong>Latitude:</strong> {{ $project->Latitude }}</p>
        </div>
        <div class="border rounded p-4 bg-gray-50">
            <p><strong>County:</strong> {{ $project->County }}</p>
            <p><strong>State:</strong> {{ $project->StateProvince }}</p>
            <p><strong>Longitude:</strong> {{ $project->Longitude }}</p>
        </div>
    </div>
</div>
